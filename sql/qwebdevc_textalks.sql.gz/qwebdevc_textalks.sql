-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 18, 2015 at 11:04 PM
-- Server version: 5.5.42-37.1-log
-- PHP Version: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qwebdevc_textalks`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `talk_id` int(11) NOT NULL,
  `comment` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `talk_id`, `comment`) VALUES
(8, 17, 'I want a comment'),
(9, 17, 'and another comment'),
(10, 17, 'asdfasdf'),
(11, 3, 'Quality FTW!');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

DROP TABLE IF EXISTS `likes`;
CREATE TABLE IF NOT EXISTS `likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `talk_id` int(11) NOT NULL,
  `like_count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `talk_id`, `like_count`) VALUES
(1, 13, 2),
(2, 17, 3),
(3, 16, 2),
(4, 11, 1),
(5, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `talks`
--

DROP TABLE IF EXISTS `talks`;
CREATE TABLE IF NOT EXISTS `talks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `youtube_id` varchar(100) NOT NULL,
  `presenter` varchar(200) NOT NULL,
  `topic` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `presentation_link` longtext NOT NULL,
  `hero_url` varchar(250) NOT NULL,
  `views` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `talks`
--

INSERT INTO `talks` (`id`, `youtube_id`, `presenter`, `topic`, `date`, `presentation_link`, `hero_url`, `views`) VALUES
(1, 'qxiMQy02CGw', 'Lisa Cutmore', 'Women in leadership ', '25 Mar 2015', 'https://docs.google.com/presentation/d/18XwM6-q_lZmCwkKbUVoksGBJ0tm3_ZO7QsM2JVNP6lI/edit#slide=id.p', '/heros/Lisa_1.jpg', 0),
(2, 'ev1QqABlYIs', 'Warwick Cox', 'How to present with confidence ', '25 Mar 2015', 'https://prezi.com/z6tmxfnby1tf/how-to-present-with-confidence/', '/heros/Warwick_4.jpg', 0),
(3, 'W0TDuJL3Ex8', 'Chris Roberts', 'Quality', '31 Mar 2015', '', '/heros/Chris_1.jpg', 2),
(4, 'ZvOxtlkyahw', 'Kristin Repsher', 'Getting out of auto ', '31 Mar 2015', 'http://www.kristinrepsher.com/Getting%20Out%20of%20Auto.pdf', '/heros/Kristin_1.jpg', 0),
(5, 'QHg1KR7uAPA', 'Warwick Cox', 'Analytics rule the world', '9 Apr 2015', 'https://prezi.com/qqb074cx457t/analytics-rules-the-world/', '/heros/Warwick_2.jpg', 0),
(6, 'CWx3w85N1Pg', 'Dan Porter', 'A Miners Life', '9 Apr 2015', 'http://slides.com/danielporter/a-miners-life#/', '/heros/Dan_1.jpg', 0),
(7, 'ZxksanRWdLg', 'Warwick Cox', 'How to present with confidence (again)', '16 Apr 2015', 'https://prezi.com/z6tmxfnby1tf/how-to-present-with-confidence/', '/heros/Warwick_4.jpg', 0),
(8, 'LaUC2Mc7FNQ', 'Pete Capra', 'Workshop: Role of the tester', '23 Apr 2015', '', '/heros/Pete_1.jpg', 0),
(9, 'Lk6McoiZ4es', 'Dineth Mendis', 'Getting the word out', '23 Apr 2015', '', '/heros/Dineth_1.jpg', 5),
(10, 'ivmcRhWftPY', 'Warwick Cox', 'Coaching: The Social Experiment ', '7 May 2015', 'http://prezi.com/vranqnlafpos/?utm_campaign=share&utm_medium=copy&rc=ex0share', '/heros/Warwick_3.jpg', 0),
(11, 'jzPvv904F-g', 'Dave Coons', 'Homeschooling FAQs', '29 Apr 2015', '', '/heros/Dave_1.jpg', 4),
(12, 'VP4nwvvwVO0', 'Eily Coghlan', 'Myers Briggs: Psychology of Personality and Behaviour', '7 May 2015', 'https://docs.google.com/presentation/d/1yLAbQiss_0iolW7l8aEecrgMovCvlR4-OeIjwidfBqQ/edit#slide=id.p', '/heros/Eily_2.jpg', 0),
(13, 'h5qYQlkjYdc', 'Sharim Chua', 'Asian Dining etiquette', '29 Apr 2015', '', '/heros/Sharim_1.jpg', 1),
(14, 'Ac7ZcexVr-g', 'Lisa Cutmore', '5:2 Fast Diet', '13 May 2015', '', '/heros/Lisa_2.jpg', 0),
(15, '86y4SomaSd8', 'Karl Ringrose', 'The Search. My surfing journey', '13 May 2015', '', '/heros/Karl_1.jpg', 5),
(16, '3p6kMyMKkC0', 'Kim Dale', 'Mental health', '20 May 2015', '', '/heros/Kim_1.jpg', 5),
(17, 'hMv5sOdWoNw', 'Group activitiy', 'Improv', '20 May 2015', '', '/heros/Improv_1.jpg', 0),
(18, '-kVRSOEfqTQ', 'Kristin Repsher', 'The importance of being (just a little) crazy', '27 May 2015', 'http://www.kristinrepsher.com/talks/Importance-of-Being-Crazy.pdf', '/heros/Kristin_2.jpg', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
